# code-of-college-in-prolog

It is a simple program for a group of college doctors that displays information about each doctor (department - specialty - degree - college - phone number - email - age) in logical programming (prolog).
